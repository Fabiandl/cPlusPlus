#ifndef MEINEKLASSE_H
#define MEINEKLASSE_H

using namespace std;

      
 class MeineKlasse{
     public:
        MeineKlasse(){}
        void aendern(int number){}
	const int & readonlyAttribut;
     
	private:
	int value;
 };
	inline void MeineKlasse::aendern(int number){value = number;};
	inline MeineKlasse::MeineKlasse(): value(0), readonlyAttribut(value){};

 #endif